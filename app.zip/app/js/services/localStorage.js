'use strict';

app.value('localStorage', window.localStorage);