function infoCtrl($scope, nav, settings) {
	$scope.nav = nav.url;
	$scope.settings = settings;
}