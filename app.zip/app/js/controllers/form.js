function formCtrl($scope, nav, settings) {
	$scope.nav = nav.url;
	$scope.settings = settings;
	
}