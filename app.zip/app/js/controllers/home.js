function homeCtrl($scope, nav, settings) {
	$scope.nav = nav.url;
	$scope.settings = settings;
}